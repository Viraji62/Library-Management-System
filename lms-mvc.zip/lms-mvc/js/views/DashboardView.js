
//  VIEW: DashboardView
//  Responsibility: Render dashboard HTML ONLY.
//  Receives data from Controller, just displays it.

class DashboardView {

  render(user, borrowedBooks, totalAvailable) {
    document.getElementById('app').innerHTML = `
      <div class="app-wrapper">
        ${this._sidebar('dashboard')}
        <main class="main-content">
          <div class="topbar">
            <div>
              <h1>Welcome Back, ${user.fullname}!</h1>
              <p style="color:#64748b;font-size:14px;">Here's your library overview for today</p>
            </div>
            ${this._topbarUser(user.fullname)}
          </div>

          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-icon blue">📘</div>
              <h2>${borrowedBooks.length}</h2>
              <p>Currently borrowed</p>
            </div>
            <div class="stat-card">
              <div class="stat-icon yellow">🕐</div>
              <h2>0</h2>
              <p>Due this week</p>
            </div>
            <div class="stat-card">
              <div class="stat-icon red">📈</div>
              <h2>0</h2>
              <p>Overdue Books</p>
            </div>
            <div class="stat-card">
              <div class="stat-icon green">📗</div>
              <h2>${totalAvailable}</h2>
              <p>Available Books</p>
            </div>
          </div>

          <div class="section-card">
            <h3>My Borrowed Books</h3>
            <div class="books-grid">
              ${borrowedBooks.length > 0
                ? borrowedBooks.map(b => `
                    <div class="book-card">
                      <img src="${b.img}" alt="${b.title}" onerror="this.src='https://placehold.co/80x100?text=Book'"/>
                      <div class="book-title">${b.title}</div>
                      <div class="book-author">${b.author}</div>
                      <button class="btn-return" data-id="${b.id}" style="margin-top:8px;padding:5px 12px;background:#fee2e2;color:#ef4444;border:none;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;">Return</button>
                    </div>`).join('')
                : '<p style="color:#94a3b8;font-size:14px;">No borrowed books yet.</p>'
              }
            </div>
          </div>
        </main>
      </div>
    `;
  }

  showMessage(message, type = '') {
    this._removeToast();
    const toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = `toast show ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => this._removeToast(), 3000);
  }

  _removeToast() {
    const old = document.getElementById('toast');
    if (old) old.remove();
  }

  _topbarUser(name) {
    return `<div class="topbar-user"><span class="user-icon">👤</span><span>${name}</span></div>`;
  }

  _sidebar(active) {
    const items = [
      { key: 'dashboard',    label: 'Dashboard',    icon: '⊞' },
      { key: 'search',       label: 'Search Books', icon: '▦' },
      { key: 'availability', label: 'Availability', icon: '📅' },
      { key: 'barcode',      label: 'My Bar Code',  icon: '⬤' },
      { key: 'cart',         label: 'Update',       icon: '🔄' },
    ];
    return `
      <aside class="sidebar">
        <div class="sidebar-logo">
          <span class="logo-icon">📖</span>
          <span>LMS</span>
        </div>
        <nav class="sidebar-nav">
          ${items.map(i => `
            <button class="nav-item ${active === i.key ? 'active' : ''}" data-page="${i.key}">
              <span class="icon">${i.icon}</span> ${i.label}
            </button>`).join('')}
        </nav>
        <div class="sidebar-logout">
          <button class="btn-logout" id="btn-logout">Logout</button>
        </div>
      </aside>`;
  }
}
