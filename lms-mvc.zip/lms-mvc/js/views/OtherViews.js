class AvailabilityView {

  render(user, books) {
    document.getElementById('app').innerHTML = `
      <div class="app-wrapper">
        ${this._sidebar('availability')}
        <main class="main-content">
          <div class="topbar">
            <h1>Book Availability</h1>
            ${this._topbarUser(user.fullname)}
          </div>
          <div style="overflow-x:auto;">
            <table class="availability-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Category</th>
                  <th>Total Copies</th>
                  <th>Available</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${books.map(b => `
                  <tr>
                    <td style="display:flex;align-items:center;gap:10px;">
                      <img src="${b.img}" onerror="this.src='https://placehold.co/36x46?text=B'" style="width:36px;height:46px;object-fit:cover;border-radius:4px;"/>
                      <strong>${b.title}</strong>
                    </td>
                    <td>${b.author}</td>
                    <td><span class="category-badge">${b.category}</span></td>
                    <td>${b.total}</td>
                    <td class="${b.available > 0 ? 'available-count' : 'status-out'}">${b.available}</td>
                    <td class="${b.available > 0 ? 'status-available' : 'status-out'}">${b.available > 0 ? 'Available' : 'Out of Stock'}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </main>
      </div>`;
  }

  showMessage(message, type = '') { _showToast(message, type); }
  _topbarUser(name) { return `<div class="topbar-user"><span class="user-icon">👤</span><span>${name}</span></div>`; }
  _sidebar(active) { return _buildSidebar(active); }
}

//  VIEW: BarcodeView

class BarcodeView {

  render(user, cartBooks) {
    document.getElementById('app').innerHTML = `
      <div class="app-wrapper">
        ${this._sidebar('barcode')}
        <main class="main-content">
          <div class="topbar">
            <h1>My Bar Code</h1>
            ${this._topbarUser(user.fullname)}
          </div>
          <div class="barcode-container">
            <div class="barcode-box">
              <div id="barcode-svg">${this._generateBarcodeSVG(user.username)}</div>
              <h3>Scan Barcode</h3>
              <p>Place the Barcode under the scanner to read</p>
            </div>

            <div class="barcode-actions">
              <button class="btn-confirm" id="btn-confirm-borrow">🔲 Confirm Borrow</button>
              <button class="btn-clear" id="btn-clear-cart">🗑 Clear</button>
            </div>

            <div class="info-note">
              ℹ Scan the Book Barcode. The system will automatically process the book borrowing.
            </div>

            <div id="cart-preview" style="margin-top:20px;">
              ${this._renderCartPreview(cartBooks)}
            </div>
          </div>
        </main>
      </div>`;
  }

  updateCartPreview(cartBooks) {
    const el = document.getElementById('cart-preview');
    if (el) el.innerHTML = this._renderCartPreview(cartBooks);
  }

  _renderCartPreview(cartBooks) {
    if (cartBooks.length === 0) return '<p style="color:#94a3b8;font-size:13px;text-align:center;">No books in cart. Go to Search Books to add books.</p>';
    return `
      <p style="font-size:13px;font-weight:600;margin-bottom:10px;color:#64748b;">Books in cart (${cartBooks.length}):</p>
      ${cartBooks.map(b => `
        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #e2e8f0;font-size:13px;">
          <img src="${b.img}" style="width:32px;height:42px;object-fit:cover;border-radius:4px;" onerror="this.src='https://placehold.co/32x42?text=B'"/>
          <div><strong>${b.title}</strong><br/><span style="color:#94a3b8">${b.author}</span></div>
        </div>`).join('')}`;
  }

  _generateBarcodeSVG(seed) {
  let bars = '';
  let positions = [];
  let totalWidth = 0;

  for (let i = 0; i < seed.length * 4 + 10; i++) {
    const w = (seed.charCodeAt(i % seed.length) + i) % 3 === 0 ? 4 : 2;
    const isBlack = (seed.charCodeAt(i % seed.length) + i) % 2 === 0;

    positions.push({ w, isBlack });
    totalWidth += w + 1;
  }

  totalWidth -= 1; // remove last extra gap
  let x = (300 - totalWidth) / 2; // center inside 300px svg

  positions.forEach(bar => {
    if (bar.isBlack) {
      bars += `<rect x="${x}" y="10" width="${bar.w}" height="90" fill="black"/>`;
    }
    x += bar.w + 1;
  });

  return `<svg width="300" height="110" xmlns="http://www.w3.org/2000/svg">${bars}</svg>`;
}

  showMessage(message, type = '') { _showToast(message, type); }
  _topbarUser(name) { return `<div class="topbar-user"><span class="user-icon">👤</span><span>${name}</span></div>`; }
  _sidebar(active) { return _buildSidebar(active); }
}


//  VIEW: CartView


class CartView {

  render(user, cartBooks) {
    document.getElementById('app').innerHTML = `
      <div class="app-wrapper">
        ${this._sidebar('cart')}
        <main class="main-content">
          <div class="topbar">
            <h1>Update</h1>
            ${this._topbarUser(user.fullname)}
          </div>
          <div class="cart-card">
            <div class="cart-header">
              <h3>Your Cart</h3>
              <button class="btn-clear-small" id="btn-clear-all">Clear</button>
            </div>
            <div id="cart-items">
              ${this._renderCartItems(cartBooks)}
            </div>
            <div class="cart-footer">
              <div class="cart-info-note">
                ℹ Review and confirm borrowing for the books in your cart.
              </div>
              <button class="btn-confirm" id="btn-confirm-borrow">🔲 Confirm Borrow</button>
            </div>
          </div>
        </main>
      </div>`;
  }

  updateCartItems(cartBooks) {
    const el = document.getElementById('cart-items');
    if (el) el.innerHTML = this._renderCartItems(cartBooks);
  }

  _renderCartItems(cartBooks) {
    if (cartBooks.length === 0) {
      return `<p style="color:#94a3b8;font-size:14px;padding:20px 0;text-align:center;">
        Cart is empty. <button data-page="search" class="nav-item" style="display:inline;padding:0;background:none;color:#2563eb;font-weight:600;cursor:pointer;border:none;">Browse books</button>
      </p>`;
    }
    return cartBooks.map(b => `
      <div class="cart-item">
        <img src="${b.img}" alt="${b.title}" onerror="this.src='https://placehold.co/50x65?text=Book'"/>
        <div class="cart-item-info">
          <div class="title">${b.title}</div>
          <div class="author">${b.author}</div>
        </div>
        <span class="cart-item-id">${b.id}</span>
        <button class="btn-delete" data-id="${b.id}">🗑</button>
      </div>`).join('');
  }

  showMessage(message, type = '') { _showToast(message, type); }
  _topbarUser(name) { return `<div class="topbar-user"><span class="user-icon">👤</span><span>${name}</span></div>`; }
  _sidebar(active) { return _buildSidebar(active); }
}


//  SHARED VIEW HELPERS (used by all views above)


function _buildSidebar(active) {
  const items = [
    { key: 'dashboard',    label: 'Dashboard',    icon: '⊞' },
    { key: 'search',       label: 'Search Books', icon: '▦' },
    { key: 'availability', label: 'Availability', icon: '📅' },
    { key: 'barcode',      label: 'My Bar Code',  icon: '⬤' },
    { key: 'cart',         label: 'Update',       icon: '🔄' },
  ];
  return `
    <aside class="sidebar">
      <div class="sidebar-logo">
        <span class="logo-icon">📖</span><span>LMS</span>
      </div>
      <nav class="sidebar-nav">
        ${items.map(i => `
          <button class="nav-item ${active === i.key ? 'active' : ''}" data-page="${i.key}">
            <span class="icon">${i.icon}</span> ${i.label}
          </button>`).join('')}
      </nav>
      <div class="sidebar-logout">
        <button class="btn-logout" id="btn-logout">Logout</button>
      </div>
    </aside>`;
}

function _showToast(message, type = '') {
  const old = document.getElementById('toast');
  if (old) old.remove();
  const toast = document.createElement('div');
  toast.id = 'toast';
  toast.className = `toast show ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => { const t = document.getElementById('toast'); if (t) t.remove(); }, 3000);
}
